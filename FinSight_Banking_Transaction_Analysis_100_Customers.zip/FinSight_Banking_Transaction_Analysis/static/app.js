document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".metric-card, .panel").forEach((el, index) => {
    el.style.animation = `riseIn .42s ease both`;
    el.style.animationDelay = `${Math.min(index * 35, 280)}ms`;
  });
  document.querySelectorAll("form").forEach(form => {
    form.addEventListener("submit", () => {
      const button = form.querySelector('button[type="submit"]');
      if (button && !form.getAttribute("action")?.includes("reset-demo")) {
        button.dataset.originalText = button.textContent;
        button.textContent = "Saving…";
      }
    });
  });
});
